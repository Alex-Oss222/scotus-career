# OT_1998CHUNK8

## Florida Prepaid Postsecondary Education Expense Board v. College Savings Bank

### Section I: Case, record, and procedural posture

- **Case Name:** Florida Prepaid Postsecondary Education Expense Board v. College Savings Bank
- **Citation or Docket:** 527 U.S. 627; No. 98-531; 148 F.3d 1343 (Fed. Cir. 1998)
- **October Term:** 1998
- **Entry Stage and Event:** Argued; merits decision pending.
- **Simulated Event Date:** June 23, 1999
- **Question Presented:** Whether Congress validly subjected nonconsenting States to private patent-infringement damages actions through the Patent and Plant Variety Protection Remedy Clarification Act.
- **Question Granted:** Whether Congress validly subjected nonconsenting States to private patent-infringement damages actions through the Patent and Plant Variety Protection Remedy Clarification Act.
- **Legal Field:** Federalism, patent law, and state sovereign immunity
- **Court and Judgment Under Review:** The Federal Circuit affirmed denial of Florida Prepaid’s sovereign-immunity defense and allowed College Savings Bank’s patent action to proceed.
- **Requested Supreme Court Judgment and Relief:** Reverse and dismiss the damages action as barred by state sovereign immunity.
- **Material Facts and Record:** College Savings alleged that Florida Prepaid, a state entity marketing prepaid tuition plans, infringed its patent for an investment method. Congress had amended the Patent Act to define States as infringers, expressly remove immunity, and make the ordinary patent remedies available against them.
- **Preservation, Threshold, and Vehicle Matters:** The statutory clarity is undisputed. The Court must identify the source of congressional abrogation before reaching patent liability. The complaint’s patent merits and damages remain for the lower courts.
- **Relevant Dates:** Argued April 20, 1999; simulated opinion-delivery date June 23, 1999.
- **Companion or Consolidated Matters:** College Savings Bank v. Florida Prepaid Postsecondary Education Expense Board, decided the same day, concerns a separate Lanham Act false-advertising action and the Trademark Remedy Clarification Act.
- **Known Participation Matter:** None identified.
- **Public Sources:** Official U.S. Reports or controlling lower-court opinion for the citation, record, posture, and historical disposition; Supreme Court docket and argument calendar for the supplied dates; Oyez for case metadata and oral-argument chronology.

#### Historical Supreme Court comparator

- **Historical Outcome and Vote:** Reversed, 5-4.
- **Historical Opinion Structure:** Rehnquist delivered the Court’s opinion; Stevens dissented, joined by Souter, Ginsburg, and Breyer.
- **Historical Holding:** The historical Court held that Article I could not abrogate immunity and that the Patent Remedy Act was not valid § 5 legislation under its congruence-and-proportionality analysis.
- **Historical Authority:** Opinion of the Court at the stated scope; any fractured issue is described above.
- **Historical Sources:** Official U.S. Reports at 527 U.S. 627; No. 98-531; 148 F.3d 1343 (Fed. Cir. 1998) and the court judgment identified above.

### Section II: Entering law and Stone's approved position

#### A. Law entering the case

- **Current Through:** Complete rendered October Term 1997 and admitted immediate judicial consequences effective before this event. Later entries in the continuity registers are excluded unless independently effective before the simulated event date.
- **Earlier Same-Term Decisions:** None completed in the supplied OT1998 packet at the time of drafting. Before adjudication, revalidate against every earlier simulated decision effective before this event.
- **Unresolved Same-Term Dependencies:** None identified.

#### Issue 1: Claim-specific § 5 enforcement for patent infringement

- **Controlling Simulated Law:** Simulated *City of Boerne v. Flores* requires claim-specific analysis. When the state conduct on which liability rests independently violates the Fourteenth Amendment, Congress may attach the remedy it supplied; when the constitutional violation includes culpability or remedial inadequacy, the plaintiff must plead and prove those predicates.
- **Current Reusable Doctrine:** Claim-specific enforcement under Fourteenth Amendment § 5.
- **Other Governing Law:** Fourteenth Amendment Due Process Clause and § 5; Patent Clause; Patent and Plant Variety Protection Remedy Clarification Act; state sovereign immunity.
- **Other Authority Used:** A patent is protected property, but statutory infringement alone is not a Due Process violation. The constitutional claim requires at least intentional or reckless state infringement and the absence or inadequacy of a state remedy capable of redressing the deprivation.
- **Open Point:** Whether College Savings can prove the alleged willful infringement and the absence or inadequacy of Florida's available remedies.

#### B. Stone's approved position

- **Stone's Controlled Judgment or Disposition:** Vacate the Federal Circuit's judgment and remand for claim-specific proceedings.
- **Stone's Remedy and Remand Instruction:** College Savings may proceed against Florida Prepaid under the federal patent remedy only if it pleads and proves that the State intentionally or recklessly infringed the patent and that Florida supplied no constitutionally adequate process or remedy. College Savings bears the burden of persuasion on both predicates. If both are established, the remedies Congress provided attach to that claim; if either fails, the direct-State claim must be dismissed on sovereign-immunity grounds.

#### Issue 1: Claim-specific § 5 enforcement for patent infringement

- **Threshold and Merits Reach:** Stone resolves sovereign immunity and the source of abrogation before patent liability. He rejects blanket validity for every statutory infringement but reaches the claim-specific § 5 route because College Savings alleged willful infringement.
- **Stone's Legal Position:** Stone applies simulated *Boerne*. The Patent Remedy Act is not valid as a blanket abrogation for innocent or merely negligent infringement where adequate state redress exists. It is valid as applied when the same state conduct independently violates Due Process, which requires intentional or reckless infringement of protected patent property and the absence or inadequacy of constitutionally sufficient state process or relief.
- **Stone's Proposed Holding:** Congress may subject a State to the federal patent remedy under § 5 when the claimant proves intentional or reckless infringement of protected patent property and the absence or inadequacy of a state remedy; statutory infringement alone does not establish valid abrogation.
- **Stone's Reasoning and Record Application:** College Savings alleged willful infringement, so the complaint presents a possible independent constitutional deprivation rather than only strict statutory liability. The existing record does not establish the required culpability or the adequacy of Florida's remedies. Simulated *Boerne* therefore requires vacatur and fact-bound remand instead of either blanket abrogation or blanket immunity.
- **Boundary or Reserved Question:** The position does not authorize federal damages for innocent or negligent infringement, for infringement accompanied by constitutionally adequate state redress, or without proof of the Patent Act's own elements. It decides no patent validity, infringement, causation, damages, or amount of relief.

---

## College Savings Bank v. Florida Prepaid Postsecondary Education Expense Board

### Section I: Case, record, and procedural posture

- **Case Name:** College Savings Bank v. Florida Prepaid Postsecondary Education Expense Board
- **Citation or Docket:** 527 U.S. 666; No. 98-149; 131 F.3d 353 (3d Cir. 1997)
- **October Term:** 1998
- **Entry Stage and Event:** Argued; merits decision pending.
- **Simulated Event Date:** June 23, 1999
- **Question Presented:** Whether Congress validly removed state sovereign immunity for a private Lanham Act false-advertising action and whether a State waives immunity by engaging in interstate commercial activity regulated by federal law.
- **Question Granted:** Whether Congress validly removed state sovereign immunity for a private Lanham Act false-advertising action and whether a State waives immunity by engaging in interstate commercial activity regulated by federal law.
- **Legal Field:** Federalism and unfair competition, Commerce Clause abrogation and waiver
- **Court and Judgment Under Review:** The Third Circuit affirmed dismissal of College Savings Bank’s Lanham Act action on sovereign-immunity grounds.
- **Requested Supreme Court Judgment and Relief:** Reverse and permit the federal false-advertising claim to proceed.
- **Material Facts and Record:** College Savings sold college-savings products and alleged that Florida Prepaid made false statements about its competing state program. The Trademark Remedy Clarification Act expressly subjected States to Lanham Act suits and remedies. Florida Prepaid entered interstate commerce but did not expressly consent to suit.
- **Preservation, Threshold, and Vehicle Matters:** The express statutory abrogation ground precedes constructive waiver. If abrogation is valid, no waiver theory is necessary. The false-advertising merits remain unresolved.
- **Relevant Dates:** Argued April 20, 1999; simulated opinion-delivery date June 23, 1999.
- **Companion or Consolidated Matters:** Florida Prepaid Postsecondary Education Expense Board v. College Savings Bank, decided the same day, concerns a separate patent-infringement action.
- **Known Participation Matter:** None identified.
- **Public Sources:** Official U.S. Reports or controlling lower-court opinion for the citation, record, posture, and historical disposition; Supreme Court docket and argument calendar for the supplied dates; Oyez for case metadata and oral-argument chronology.

#### Historical Supreme Court comparator

- **Historical Outcome and Vote:** Affirmed, 5-4.
- **Historical Opinion Structure:** Scalia delivered the Court’s opinion; Breyer dissented, joined by Stevens, Souter, and Ginsburg.
- **Historical Holding:** The historical Court held the Commerce Clause insufficient for abrogation and rejected constructive waiver based on commercial activity.
- **Historical Authority:** Opinion of the Court at the stated scope; any fractured issue is described above.
- **Historical Sources:** Official U.S. Reports at 527 U.S. 666; No. 98-149; 131 F.3d 353 (3d Cir. 1997) and the court judgment identified above.

### Section II: Entering law and Stone's approved position

#### A. Law entering the case

- **Current Through:** Complete rendered October Term 1997 and admitted immediate judicial consequences effective before this event. Later entries in the continuity registers are excluded unless independently effective before the simulated event date.
- **Earlier Same-Term Decisions:** None completed in the supplied OT1998 packet at the time of drafting. Before adjudication, revalidate against every earlier simulated decision effective before this event.
- **Unresolved Same-Term Dependencies:** None identified.

#### Issue 1: Fourteenth Amendment property and damages abrogation

- **Controlling Simulated Law:** Simulated *City of Boerne v. Flores* requires claim-specific correspondence between the enacted remedy and conduct that independently violates the Fourteenth Amendment.
- **Current Reusable Doctrine:** Claim-specific enforcement under Fourteenth Amendment § 5.
- **Other Governing Law:** Fourteenth Amendment Due Process Clause and § 5; Lanham Act; Trademark Remedy Clarification Act.
- **Other Authority Used:** Competitive injury from a rival's statements about its own product is not deprivation of the claimant's property absent appropriation or destruction of an independently protected asset.

#### Issue 2: Constructive waiver through commercial activity

- **Controlling Simulated Law:** No supplied simulated holding makes regulated market participation an unequivocal consent to suit. *Parden v. Terminal Railway* supplies the contrary constructive-waiver rule that Stone confronts directly.
- **Current Reusable Doctrine:** No separately registered waiver test is identified beyond the requirement that waiver rest on a clear and voluntary manifestation of state consent.
- **Other Governing Law:** State sovereign immunity; waiver doctrine; Lanham Act.
- **Other Authority Used:** Express consent, voluntary invocation of federal jurisdiction, and a separately valid condition accepted with clear notice remain distinct waiver routes.

#### Issue 3: Expressly authorized prospective Lanham Act relief

- **Controlling Simulated Law:** Simulated *Seminole Tribe v. Florida* holds that Congress may authorize a prospective federal action directly against a State when it unmistakably identifies the State as defendant, acts within an enumerated commerce power, and expressly supplies the cause of action and bounded prospective remedy; it does not authorize damages.
- **Current Reusable Doctrine:** Article I abrogation of state sovereign immunity under IGRA.
- **Other Governing Law:** Commerce Clause; Lanham Act; Trademark Remedy Clarification Act; Article III standing and equitable-remedy requirements.
- **Other Authority Used:** The Trademark Remedy Clarification Act expressly identifies States as defendants and makes Lanham Act injunctive relief available, while retrospective monetary relief remains outside simulated *Seminole*'s boundary.

#### B. Stone's approved position

- **Stone's Controlled Judgment or Disposition:** Affirm the Third Circuit's judgment as to damages, reverse it as to the expressly authorized prospective Lanham Act claim, and remand.
- **Stone's Remedy and Remand Instruction:** The dismissal of monetary and retrospective claims remains in force. On remand, College Savings may pursue declaratory or injunctive relief against Florida Prepaid only for an ongoing or sufficiently imminent Lanham Act violation. The lower courts must resolve standing, recurrence, falsity, materiality, injury, causation, and equitable fit before granting relief.

#### Issue 1: Fourteenth Amendment property and damages abrogation

- **Threshold and Merits Reach:** Stone reaches the § 5 theory because it is asserted as an independent basis for monetary liability.
- **Stone's Legal Position:** Competitive injury from a rival's statements about its own product is not, without appropriation or destruction of an independently protected asset, a Fourteenth Amendment property deprivation. Simulated *Boerne* therefore supplies no valid § 5 abrogation for damages on the claim pleaded here.
- **Stone's Proposed Holding:** Competitive injury from a rival's false statements about its own product is not a Fourteenth Amendment property deprivation absent appropriation or destruction of an independently protected asset; the Trademark Remedy Clarification Act cannot abrogate immunity for damages on this claim under § 5.
- **Stone's Reasoning and Record Application:** College Savings alleges lost competitive advantage from Florida Prepaid's representations about Florida's own program, not seizure or destruction of property belonging to the Bank. A federal unfair-competition cause of action does not convert that commercial injury into a constitutional deprivation.
- **Boundary or Reserved Question:** The holding does not decide a materially different claim involving appropriation or destruction of protected property or another independently established Fourteenth Amendment violation.

#### Issue 2: Constructive waiver through commercial activity

- **Threshold and Merits Reach:** Stone reaches and rejects constructive waiver as an asserted independent route to both monetary and prospective suit.
- **Stone's Legal Position:** Stone overrules *Parden* to the extent it treats participation in federally regulated interstate commerce as constructive consent to private suit. Market participation may subject the State to valid substantive federal law, but it does not communicate the unequivocal and voluntary surrender of immunity that waiver requires.
- **Stone's Proposed Holding:** A State does not waive sovereign immunity merely by engaging in interstate commercial activity subject to federal regulation; waiver requires an unequivocal, voluntary manifestation of consent.
- **Stone's Reasoning and Record Application:** Florida Prepaid enacted no consent, made no litigation commitment, and did not voluntarily invoke federal jurisdiction. Constructive waiver would make consent turn on congressional regulation rather than the State's own legal act and would collapse the distinction between substantive federal power and remedial permission to sue the State.
- **Boundary or Reserved Question:** The holding leaves genuine express consent, voluntary invocation of federal jurisdiction, and separately valid conditions accepted with clear notice intact.

#### Issue 3: Expressly authorized prospective Lanham Act relief

- **Threshold and Merits Reach:** Stone reaches the prospective component because the Act expressly authorizes suit against States and the Third Circuit dismissed the entire action. The underlying Lanham Act merits and equitable predicates remain for remand.
- **Stone's Legal Position:** Stone applies simulated *Seminole* without alteration. The Trademark Remedy Clarification Act unmistakably identifies States as defendants, rests on Congress's Commerce Clause authority over interstate false advertising, and expressly makes prospective Lanham Act relief available. Simulated *Seminole* therefore permits the bounded prospective action even though it forecloses damages.
- **Stone's Proposed Holding:** Under simulated *Seminole*, Congress may authorize a private prospective Lanham Act action directly against a State under the Commerce Clause when the statute clearly identifies the State as defendant and supplies an express injunctive remedy; the Trademark Remedy Clarification Act satisfies those conditions.
- **Stone's Reasoning and Record Application:** The statutory text gives Florida Prepaid clear notice of the federal cause of action and the prospective remedy. Allowing an injunction against ongoing or imminent false advertising enforces the enacted federal rule without imposing retrospective treasury liability, preserving the exact remedial line simulated *Seminole* drew.
- **Boundary or Reserved Question:** The holding authorizes no damages, restitution, retrospective compensation, or injunction based only on completed conduct lacking a real threat of recurrence. It decides no Lanham Act merits or entitlement to equitable relief.

---

## Alden v. Maine

### Section I: Case, record, and procedural posture

- **Case Name:** Alden v. Maine
- **Citation or Docket:** 527 U.S. 706; No. 98-436; 715 A.2d 172 (Me. 1998)
- **October Term:** 1998
- **Entry Stage and Event:** Argued; merits decision pending.
- **Simulated Event Date:** June 23, 1999
- **Question Presented:** Whether Congress may require a nonconsenting State to answer in its own courts to a private damages action under the Fair Labor Standards Act enacted pursuant to the Commerce Clause.
- **Question Granted:** Whether Congress may require a nonconsenting State to answer in its own courts to a private damages action under the Fair Labor Standards Act enacted pursuant to the Commerce Clause.
- **Legal Field:** Federalism, state-court sovereign immunity, and federal wage law
- **Court and Judgment Under Review:** The Supreme Judicial Court of Maine affirmed dismissal of state probation officers’ FLSA overtime action on state sovereign-immunity grounds.
- **Requested Supreme Court Judgment and Relief:** Reverse and require Maine’s courts to hear the federal claim.
- **Material Facts and Record:** State probation officers alleged that Maine denied overtime compensation required by the FLSA. After their federal action encountered immunity, they filed in state court. The FLSA expressly included public agencies and authorized employee actions against state employers in a court of competent jurisdiction.
- **Preservation, Threshold, and Vehicle Matters:** The federal statute clearly covers Maine and supplies a private damages action. The question is whether state sovereign immunity can defeat that valid federal command in a state forum otherwise competent to hear comparable claims.
- **Relevant Dates:** Argued March 31, 1999; simulated opinion-delivery date June 23, 1999.
- **Companion or Consolidated Matters:** None.
- **Known Participation Matter:** None identified.
- **Public Sources:** Official U.S. Reports or controlling lower-court opinion for the citation, record, posture, and historical disposition; Supreme Court docket and argument calendar for the supplied dates; Oyez for case metadata and oral-argument chronology.

#### Historical Supreme Court comparator

- **Historical Outcome and Vote:** Affirmed, 5-4.
- **Historical Opinion Structure:** Kennedy delivered the Court’s opinion; Souter dissented, joined by Stevens, Ginsburg, and Breyer.
- **Historical Holding:** The historical Court recognized constitutional state sovereign immunity in state court beyond the Eleventh Amendment and held Article I insufficient to subject a nonconsenting State to the FLSA action.
- **Historical Authority:** Opinion of the Court at the stated scope; any fractured issue is described above.
- **Historical Sources:** Official U.S. Reports at 527 U.S. 706; No. 98-436; 715 A.2d 172 (Me. 1998) and the court judgment identified above.

### Section II: Entering law and Stone's approved position

#### A. Law entering the case

- **Current Through:** Complete rendered October Term 1997 and admitted immediate judicial consequences effective before this event. Later entries in the continuity registers are excluded unless independently effective before the simulated event date.
- **Earlier Same-Term Decisions:** None completed in the supplied OT1998 packet at the time of drafting. Before adjudication, revalidate against every earlier simulated decision effective before this event.
- **Unresolved Same-Term Dependencies:** None identified.

#### Issue 1: Private Article I damages action against a State in state court

- **Controlling Simulated Law:** Simulated *Seminole Tribe v. Florida* governs an unmistakably authorized prospective Article I action against a State in federal court and expressly denies damages; it does not decide private state-court treasury actions. No supplied simulated precedent establishes an earned-compensation or specific-restitution exception.
- **Current Reusable Doctrine:** Article I abrogation of state sovereign immunity under IGRA, under Federalism, supplies the current direct-State and remedy boundary requiring extension to the state-court setting.
- **Other Governing Law:** Commerce Clause; Supremacy Clause; FLSA public-employer coverage and private action; structural state sovereign immunity.
- **Other Authority Used:** *Garcia v. San Antonio Metropolitan Transit Authority* confirms the substantive FLSA power; *Testa v. Katt* and *Howlett v. Rose* prevent discriminatory closure to federal law but do not erase a defendant's generally applicable constitutional immunity.

#### B. Stone's approved position

- **Stone's Controlled Judgment or Disposition:** Affirm the Supreme Judicial Court of Maine's judgment dismissing the private action against Maine.
- **Stone's Remedy and Remand Instruction:** No separate remedial instruction is required. The dismissal does not bar federal enforcement, unequivocal state waiver, valid Reconstruction-amendment abrogation, prospective relief against responsible officers, or relief Maine itself lawfully makes available.

#### Issue 1: Private Article I damages action against a State in state court

- **Threshold and Merits Reach:** Stone reaches the structural-immunity question. Employee-specific coverage, hours, rates, defenses, and amounts are unnecessary once the direct-State treasury action is unavailable.
- **Stone's Legal Position:** The FLSA validly regulates Maine as an employer under *Garcia*, but Article I does not authorize a private direct-State treasury action in the State's own court. Stone recognizes that centralized public enforcement predictably leaves valid wage violations underremedied and that private enforcement would likely perform better. That enforcement deficit cannot create remedial authority that simulated *Seminole* withholds; reversal would require candidly modifying the no-damages boundary to permit private compensatory claims for earned wages, a change Stone declines on the present sources.
- **Stone's Proposed Holding:** Congress may not use Article I to subject a nonconsenting State to a private damages action in its own courts. Characterizing accrued FLSA liability as earned compensation or make-whole restitution does not alter the direct State defendant or retrospective treasury remedy.
- **Stone's Reasoning and Record Application:** *Testa* and *Howlett* require nondiscriminatory enforcement of federal law in competent state courts, but they do not remove a constitutional immunity belonging to the defendant. The record-supported enforcement concern is serious, yet practical necessity cannot create a private damages channel. Federal supremacy remains enforceable through the United States, lawful officer relief, waiver, valid Reconstruction legislation, and remedies Maine itself provides.
- **Boundary or Reserved Question:** The position does not deny the substantive FLSA duty, approve underenforcement, authorize Maine to violate federal law, or bar unequivocal waiver, valid Reconstruction-amendment abrogation, suit by the United States, prospective relief against responsible officers, or relief the State itself makes available.

---

## Ortiz v. Fibreboard Corp.

### Section I: Case, record, and procedural posture

- **Case Name:** Ortiz v. Fibreboard Corp.
- **Citation or Docket:** 527 U.S. 815; No. 97-1704; 134 F.3d 668 (5th Cir. 1998)
- **October Term:** 1998
- **Entry Stage and Event:** Argued; merits decision pending.
- **Simulated Event Date:** June 23, 1999
- **Question Presented:** Whether the asbestos settlement class satisfied Rule 23(b)(1)(B)’s limited-fund requirements and Rule 23(a)’s adequacy protections for persons with present and future claims.
- **Question Granted:** Whether the asbestos settlement class satisfied Rule 23(b)(1)(B)’s limited-fund requirements and Rule 23(a)’s adequacy protections for persons with present and future claims.
- **Legal Field:** Civil procedure, mandatory limited-fund class settlement
- **Court and Judgment Under Review:** The Fifth Circuit affirmed certification and approval of a mandatory global settlement class against Fibreboard.
- **Requested Supreme Court Judgment and Relief:** Affirm the settlement and mandatory class certification.
- **Material Facts and Record:** Fibreboard, its insurers, and selected plaintiffs negotiated a settlement intended to resolve a vast range of present and future asbestos claims. The certified class had no opt-out right. The asserted limited fund was derived largely from the negotiated insurance contribution rather than a judicial finding of Fibreboard’s maximum assets, and class members had materially different exposure, disease, timing, and insurance interests.
- **Preservation, Threshold, and Vehicle Matters:** Objecting class members may challenge certification and adequacy. Settlement is relevant to manageability but cannot relax Rule 23’s structural requirements or cure conflicted representation.
- **Relevant Dates:** Argued December 8, 1998; simulated opinion-delivery date June 23, 1999.
- **Companion or Consolidated Matters:** None.
- **Known Participation Matter:** None identified.
- **Public Sources:** Official U.S. Reports or controlling lower-court opinion for the citation, record, posture, and historical disposition; Supreme Court docket and argument calendar for the supplied dates; Oyez for case metadata and oral-argument chronology.

#### Historical Supreme Court comparator

- **Historical Outcome and Vote:** Reversed, 9-0.
- **Historical Opinion Structure:** Souter delivered a unanimous Court opinion.
- **Historical Holding:** The class failed the traditional limited-fund prerequisites and adequate-representation requirements; the mandatory settlement could not stand.
- **Historical Authority:** Opinion of the Court at the stated scope; any fractured issue is described above.
- **Historical Sources:** Official U.S. Reports at 527 U.S. 815; No. 97-1704; 134 F.3d 668 (5th Cir. 1998) and the court judgment identified above.

### Section II: Entering law and Stone's approved position

#### A. Law entering the case

- **Current Through:** Complete rendered October Term 1997 and admitted immediate judicial consequences effective before this event. Later entries in the continuity registers are excluded unless independently effective before the simulated event date.
- **Earlier Same-Term Decisions:** None completed in the supplied OT1998 packet at the time of drafting. Before adjudication, revalidate against every earlier simulated decision effective before this event.
- **Unresolved Same-Term Dependencies:** None identified.

#### Issue 1: Rule 23(b)(1)(B) limited fund and adequate representation

- **Controlling Simulated Law:** Amchem Products, Inc. v. Windsor requires every settlement class to satisfy Rule 23 and holds that settlement does not relax predominance or adequate representation where present and future claimants conflict.
- **Current Reusable Doctrine:** Settlement-only class certification under Rule 23, under Civil Procedure, supplies the operative requirement and permits narrower subclasses and individual resolution.
- **Other Governing Law:** Federal Rule of Civil Procedure 23(a) and 23(b)(1)(B); Due Process Clause.
- **Other Authority Used:** Traditional limited-fund practice requires a fund fixed independently of the settlement, inadequate to pay all claims, wholly devoted to the class, and distributed through equitable treatment among claimants.

#### B. Stone's approved position

- **Stone's Controlled Judgment or Disposition:** Reverse the Fifth Circuit’s judgment and remand.
- **Stone's Remedy and Remand Instruction:** The mandatory class certification and settlement approval shall be vacated. The parties may pursue individual settlements, narrower opt-out classes, separately represented subclasses, bankruptcy, or a genuine limited-fund proceeding satisfying Rule 23 and due process.

#### Issue 1: Rule 23(b)(1)(B) limited fund and adequate representation

- **Threshold and Merits Reach:** Stone reaches the merits; no dispositive threshold issue is identified.
- **Stone's Legal Position:** Stone applies the traditional limited-fund category narrowly because mandatory aggregation eliminates individual control and opt-out. The parties may not manufacture the fund’s limit through negotiation, reserve value outside the class, or use one representation structure for materially opposed claimant groups.
- **Stone's Proposed Holding:** A mandatory settlement class under Rule 23(b)(1)(B) requires a demonstrated fund fixed independently at its maximum practical value, insufficiency to satisfy the aggregate claims, commitment of substantially the whole fund, equitable distribution, and adequate conflict-free representation, including separate subclasses where present and future claimants materially diverge.
- **Stone's Reasoning and Record Application:** The record did not establish Fibreboard’s total available value independently of the agreement, the settlement preserved disputed value and preferential arrangements, and the single class structure did not adequately represent present injuries, future disease, and varying insurance interests. Certification therefore fails.
- **Boundary or Reserved Question:** The holding does not bar mass-tort settlements, bankruptcy trusts, opt-out damages classes that satisfy Rule 23(b)(3), genuine limited funds, or settlements with separately represented subclasses and lawful notice protections.

---

## Complete Chunk Index

| Chunk | Case | Assigned date | Stage |
|---|---|---:|---|
| OT_1998CHUNK1 | *Marquez v. Screen Actors Guild, Inc.* | November 3, 1998 | Merits, not a certiorari petition |
| OT_1998CHUNK1 | *Pfaff v. Wells Electronics, Inc.* | November 10, 1998 | Merits, not a certiorari petition |
| OT_1998CHUNK1 | *Wright v. Universal Maritime Service Corp.* | November 16, 1998 | Merits, not a certiorari petition |
| OT_1998CHUNK1 | *Minnesota v. Carter* | December 1, 1998 | Merits, not a certiorari petition |
| OT_1998CHUNK1 | *Knowles v. Iowa* | December 8, 1998 | Merits, not a certiorari petition |
| OT_1998CHUNK1 | *Haddle v. Garrison* | December 14, 1998 | Merits, not a certiorari petition |
| OT_1998CHUNK1 | *NYNEX Corp. v. Discon, Inc.* | December 14, 1998 | Merits, not a certiorari petition |
| OT_1998CHUNK1 | *El Al Israel Airlines, Ltd. v. Tsui Yuan Tseng* | January 12, 1999 | Merits, not a certiorari petition |
| OT_1998CHUNK1 | *Buckley v. American Constitutional Law Foundation, Inc.* | January 12, 1999 | Merits, not a certiorari petition |
| OT_1998CHUNK1 | *City of West Covina v. Perkins* | January 13, 1999 | Merits, not a certiorari petition |
| OT_1998CHUNK2 | *Department of the Army v. Blue Fox, Inc.* | January 20, 1999 | Merits, not a certiorari petition |
| OT_1998CHUNK2 | *Lopez v. Monterey County* | January 20, 1999 | Merits, not a certiorari petition |
| OT_1998CHUNK2 | *Humana Inc. v. Forsyth* | January 20, 1999 | Merits, not a certiorari petition |
| OT_1998CHUNK2 | *Department of Commerce v. United States House of Representatives; Clinton v. Glavin* | January 25, 1999 | Merits, not a certiorari petition |
| OT_1998CHUNK2 | *AT&T Corp. v. Iowa Utilities Board* | January 25, 1999 | Merits, not a certiorari petition |
| OT_1998CHUNK2 | *Hughes Aircraft Co. v. Jacobson* | January 25, 1999 | Merits, not a certiorari petition |
| OT_1998CHUNK2 | *Boring v. Buncombe County Board of Education* | February 17, 1999† | Post-grant merits; simulated grant already entered |
| OT_1998CHUNK2 | *National Collegiate Athletic Association v. Smith* | February 23, 1999 | Merits, not a certiorari petition |
| OT_1998CHUNK2 | *Reno v. American-Arab Anti-Discrimination Committee* | February 24, 1999 | Merits, not a certiorari petition |
| OT_1998CHUNK2 | *Holloway v. United States* | March 2, 1999 | Merits, not a certiorari petition |
| OT_1998CHUNK3 | *Cedar Rapids Community School District v. Garret F.* | March 3, 1999 | Merits, not a certiorari petition |
| OT_1998CHUNK3 | *American Manufacturers Mutual Insurance Co. v. Sullivan* | March 3, 1999 | Merits, not a certiorari petition |
| OT_1998CHUNK3 | *Jackson v. Benson* | March 16, 1999† | Post-grant merits; simulated grant already entered |
| OT_1998CHUNK3 | *Kumho Tire Co. v. Carmichael* | March 23, 1999 | Merits, not a certiorari petition |
| OT_1998CHUNK3 | *South Central Bell Telephone Co. v. Alabama* | March 23, 1999 | Merits, not a certiorari petition |
| OT_1998CHUNK3 | *Jones v. United States* | March 24, 1999 | Merits, not a certiorari petition |
| OT_1998CHUNK3 | *Minnesota v. Mille Lacs Band of Chippewa Indians* | March 24, 1999 | Merits, not a certiorari petition |
| OT_1998CHUNK3 | *United States v. Rodriguez-Moreno* | March 30, 1999 | Merits, not a certiorari petition |
| OT_1998CHUNK3 | *Murphy Brothers, Inc. v. Michetti Pipe Stringing, Inc.* | April 5, 1999 | Merits, not a certiorari petition |
| OT_1998CHUNK3 | *Mitchell v. United States* | April 5, 1999 | Merits, not a certiorari petition |
| OT_1998CHUNK4 | *Wyoming v. Houghton* | April 5, 1999 | Merits, not a certiorari petition |
| OT_1998CHUNK4 | *In re Sealed Case* | April 13, 1999† | Post-grant merits; simulated grant already entered |
| OT_1998CHUNK4 | *UNUM Life Insurance Co. of America v. Ward* | April 20, 1999 | Merits, not a certiorari petition |
| OT_1998CHUNK4 | *United States v. Sun-Diamond Growers of California* | April 27, 1999 | Merits, not a certiorari petition |
| OT_1998CHUNK4 | *Russell v. Burris* | April 28, 1999† | Post-grant merits; simulated grant already entered |
| OT_1998CHUNK4 | *INS v. Aguirre-Aguirre* | May 3, 1999 | Merits, not a certiorari petition |
| OT_1998CHUNK4 | *Bank of America National Trust & Savings Ass’n v. 203 North LaSalle Street Partnership* | May 3, 1999 | Merits, not a certiorari petition |
| OT_1998CHUNK4 | *El Paso Natural Gas Co. v. Neztsosie* | May 3, 1999 | Merits, not a certiorari petition |
| OT_1998CHUNK4 | *Redmon v. United States* | May 10, 1999† | Post-grant merits; simulated grant already entered |
| OT_1998CHUNK4 | *Saenz v. Roe* | May 17, 1999 | Merits, not a certiorari petition |
| OT_1998CHUNK5 | *Clinton v. Goldsmith* | May 17, 1999 | Merits, not a certiorari petition |
| OT_1998CHUNK5 | *Hunt v. Cromartie* | May 17, 1999 | Merits, not a certiorari petition |
| OT_1998CHUNK5 | *Florida v. White* | May 17, 1999 | Merits, not a certiorari petition |
| OT_1998CHUNK5 | *Ruhrgas AG v. Marathon Oil Co.* | May 17, 1999 | Merits, not a certiorari petition |
| OT_1998CHUNK5 | *Cleveland v. Policy Management Systems Corp.* | May 24, 1999 | Merits, not a certiorari petition |
| OT_1998CHUNK5 | *Wilson v. Layne* | May 24, 1999 | Merits, not a certiorari petition |
| OT_1998CHUNK5 | *Davis v. Monroe County Board of Education* | May 24, 1999 | Merits, not a certiorari petition |
| OT_1998CHUNK5 | *City of Monterey v. Del Monte Dunes at Monterey, Ltd.* | May 24, 1999 | Merits, not a certiorari petition |
| OT_1998CHUNK5 | *California Dental Association v. Federal Trade Commission* | May 24, 1999 | Merits, not a certiorari petition |
| OT_1998CHUNK5 | *Richardson v. United States* | June 1, 1999 | Merits, not a certiorari petition |
| OT_1998CHUNK6 | *Reno v. Goncalves* | June 3, 1999† | Post-grant merits; simulated grant already entered |
| OT_1998CHUNK6 | *O’Sullivan v. Boerckel* | June 7, 1999 | Merits, not a certiorari petition |
| OT_1998CHUNK6 | *Neder v. United States* | June 10, 1999 | Merits, not a certiorari petition |
| OT_1998CHUNK6 | *City of Chicago v. Morales* | June 10, 1999 | Merits, not a certiorari petition |
| OT_1998CHUNK6 | *Lilly v. Virginia* | June 10, 1999 | Merits, not a certiorari petition |
| OT_1998CHUNK6 | *Dickinson v. Zurko* | June 10, 1999 | Merits, not a certiorari petition |
| OT_1998CHUNK6 | *Greater New Orleans Broadcasting Association, Inc. v. United States* | June 14, 1999 | Merits, not a certiorari petition |
| OT_1998CHUNK6 | *Cunningham v. Hamilton County* | June 14, 1999 | Merits, not a certiorari petition |
| OT_1998CHUNK6 | *Schleifer v. City of Charlottesville* | June 15, 1999† | Post-grant merits; simulated grant already entered |
| OT_1998CHUNK6 | *National Aeronautics and Space Administration v. Federal Labor Relations Authority* | June 17, 1999 | Merits, not a certiorari petition |
| OT_1998CHUNK7 | *Strickler v. Greene* | June 17, 1999 | Merits, not a certiorari petition |
| OT_1998CHUNK7 | *Grupo Mexicano de Desarrollo, S.A. v. Alliance Bond Fund, Inc.* | June 17, 1999 | Merits, not a certiorari petition |
| OT_1998CHUNK7 | *City of Dallas v. Dallas Fire Fighters Association* | June 18, 1999† | Post-grant merits; simulated grant already entered |
| OT_1998CHUNK7 | *Martin v. Hadix* | June 21, 1999 | Merits, not a certiorari petition |
| OT_1998CHUNK7 | *Jefferson County v. Acker* | June 21, 1999 | Merits, not a certiorari petition |
| OT_1998CHUNK7 | *Sutton v. United Air Lines, Inc.* | June 22, 1999 | Merits, not a certiorari petition |
| OT_1998CHUNK7 | *Albertson’s, Inc. v. Kirkingburg* | June 22, 1999 | Merits, not a certiorari petition |
| OT_1998CHUNK7 | *Olmstead v. L.C.* | June 22, 1999 | Merits, not a certiorari petition |
| OT_1998CHUNK7 | *Murphy v. United Parcel Service, Inc.* | June 22, 1999 | Merits, not a certiorari petition |
| OT_1998CHUNK7 | *Kolstad v. American Dental Association* | June 22, 1999 | Merits, not a certiorari petition |
| OT_1998CHUNK8 | *Florida Prepaid Postsecondary Education Expense Board v. College Savings Bank* | June 23, 1999 | Merits, not a certiorari petition |
| OT_1998CHUNK8 | *College Savings Bank v. Florida Prepaid Postsecondary Education Expense Board* | June 23, 1999 | Merits, not a certiorari petition |
| OT_1998CHUNK8 | *Alden v. Maine* | June 23, 1999 | Merits, not a certiorari petition |
| OT_1998CHUNK8 | *Ortiz v. Fibreboard Corp.* | June 23, 1999 | Merits, not a certiorari petition |

**Certiorari petitions:** None in the supplied case list.
